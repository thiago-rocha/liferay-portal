aui-text-unicode
========
